﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Prova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[3, 2];
            double[] mediaf1 = new double[3];
            double[] mediaf2 = new double[3];
            double notas;
            

            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0; coluna < 2; coluna++)
                {

                    string valor = Interaction.InputBox(
                        "Digite a nota para o primeiro filme" +
                        notas(coluna), +"Para o segundo filme"(coluna + 1),
                    mediaf1[linha, coluna] = valor;
                


                    if (double.TryParse(notas: out double resultado))
                    {
                        matriz[linha, coluna] = resultado;
                    
                    else
                    {
                        MessageBox.Show("Valor inválido. Digite um número.");
                        coluna--;
                    }
                    if (valor) == "")
                    {
                        return;
                    }
                }


                    for (int linha = 0; linha < 3; linha++)
                    {
                        double soma = 0;

                        
                        for (int coluna = 0; coluna < 2; coluna++)
                        {
                            soma += matriz[linha, coluna];
                        }

                        
                        [linha] = soma;

                        
                        += soma;
                    }
                }
            }
        }
    }
}
